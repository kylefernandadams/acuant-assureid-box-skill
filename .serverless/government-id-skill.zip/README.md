Government ID extraction Box Skill example powered by Acuant AssureID
=====================================================================

Creating and Deploying the Box Skill Example
--------------------------------------------
Follow instructions found at [Creating a Box Skill](https://developer.box.com/docs/creating-your-a-box-skill-using-serverless)
